<?php
$favColor = "A";

switch ($favColor){
    case "B";
        echo "Your favorite color is red!";
        break;

    case "C";
        echo "Your favorite color is blue!";
        break;

    case "A";
        echo "Your favorite color is green!";
        break;

    default:
        echo "Your favorite color is neither red, blue, or green!";

}