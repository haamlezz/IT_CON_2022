<?php 

$score = 100;

if($score > 70){
    echo "ເຈົ້າເປັນນັກຮຽນດີ";
}